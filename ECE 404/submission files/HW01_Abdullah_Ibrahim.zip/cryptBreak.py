#Homework Nummber: 1
#Name: Ibrahim Abdullah
#ECN Login: iabdulla
#Due Date: 1/18/2024

from BitVector import *

def cryptBreak(cipherText, key_bv):
    PassPhrase = "Hopes and dreams of a million years"                          

    BLOCKSIZE = 16   
    numbytes = BLOCKSIZE // 8  

    bv_iv = BitVector(bitlist = [0]*BLOCKSIZE)            
    msg_decrypted_bv = BitVector( size = 0 )

    for i in range(0,len(PassPhrase) // numbytes):                              
        textstr = PassPhrase[i*numbytes:(i+1)*numbytes]                         
        bv_iv ^= BitVector( textstring = textstr ) 

    FILEIN = open(cipherText)
    encrypted_bv = BitVector( hexstring = FILEIN.read() )      
    FILEIN.close()
    previous_decrypted_block = bv_iv
    for i in range(2**16):
        msg_decrypted_bv = BitVector(size = 0)                                     
        for j in range(0, len(encrypted_bv) // BLOCKSIZE):                         
            bv = encrypted_bv[j*BLOCKSIZE:(j+1)*BLOCKSIZE]                           
            temp = bv.deep_copy()                                                   
            bv ^=  previous_decrypted_block                                         
            previous_decrypted_block = temp                                         
            bv ^=  key_bv                                                           
            msg_decrypted_bv += bv
            
        outputtext = msg_decrypted_bv.get_text_from_bitvector()    
    return outputtext